import { Container, Row, Col, Carousel, Button, Card } from "react-bootstrap";
import "./Index.css";
import "./app.jsx"


function Index() {
  return (
    <div>
      <br />
      <br />
      {/* Slider/Carrusel */}
      <Carousel className="carousel-container mb-5">
        <Carousel.Item>
          <img
            className="d-block w-100"
            src="https://images.pexels.com/photos/11279906/pexels-photo-11279906.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
            alt="First slide"
          />
          <Carousel.Caption>
            <h3>Bienvenido a Tu Banco electronico</h3>
            <p>Soluciones financieras que se adaptan a ti.</p>
            <Button variant="primary">Descubre más</Button>
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item>
          <img
            className="d-block w-100"
            src="https://images.pexels.com/photos/730547/pexels-photo-730547.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
            alt="Second slide"
          />
          <Carousel.Caption>
            <h3>Tus finanzas en buenas manos</h3>
            <p>Seguridad y confianza en cada transacción.</p>
            <Button variant="primary">Conoce más</Button>
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item>
          <img
            className="d-block w-100"
            src="https://cdn.pixabay.com/photo/2017/11/01/11/34/bank-2907728_1280.jpg"
            alt="Third slide"
          />
          <Carousel.Caption>
            <h3>Planifica tu futuro financiero</h3>
            <p>Con nosotros, tus metas están más cerca.</p>
            <Button variant="primary">Empieza hoy</Button>
          </Carousel.Caption>
        </Carousel.Item>
      </Carousel>

      {/* Sección de servicios */}
      <Container>
        <h2 className="text-center mb-5">Nuestros Servicios</h2>
        <Row>
          <Col md={6} className="mb-4">
            <Card className="h-200 shadow-lg">
              <Card.Img
                variant="top"
                src="https://images.pexels.com/photos/5198284/pexels-photo-5198284.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
              />
              <Card.Body>
                <Card.Title>Cuentas Bancarias</Card.Title>
                <Card.Text>
                  Abre tu cuenta de ahorro o corriente de manera rápida y sin
                  complicaciones.
                </Card.Text>
                <Button variant="primary">Abrir Cuenta</Button>
              </Card.Body>
            </Card>
          </Col>
          <Col md={6} className="mb-4">
            <Card className="h-100 shadow-lg">
              <Card.Img
                variant="top"
                src="https://images.pexels.com/photos/158776/euro-money-currency-the-european-158776.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
              />
              <Card.Body>
                <Card.Title>Inversiones</Card.Title>
                <Card.Text>
                  Haz crecer tu dinero con nuestras opciones de inversión
                  seguras y rentables.
                </Card.Text>
                <Button variant="primary">Invertir Ahora</Button>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Container>

      {/* Sección de contacto */}
      <Container className="contact-section py-5 mt-5 text-black">
        <h2 className="text-center">Contáctanos</h2>
        <Row>
          <Col md={6}>
            <h4>Atención al Cliente</h4>
            <p>Teléfono: 123-456</p>
            <p>Email: soporte@banco.com</p>
          </Col>
          <Col md={6}>
            <h4>Visítanos</h4>
            <p>Dirección: Calle ciega 457, Ciudad del dinero</p>
            <h4>INTEGRANTES</h4>
            <p>ALEJANDRO ANGARITA VILLADA</p>

          </Col>
        </Row>
      </Container>
    </div>
  );
}

export default Index;
